﻿$source = 'D:\1c\base1'
$destination = 'D:\1c_backup'


# Путь к консольному архиватору 7zip
$7zip = "C:\Program Files\7-Zip\7z.exe"

$action = @(
    'Dayly',   # каждый день в 23.00
    'Weekly',  # каждый седьмой день месяца в 23.00
    'Monthly'  # каждое первое число месяца в 23.00
)






$base = $source + 'D:\1c\base1\'
$archiv = $destination + '\base1.zip'

&$7zip a -tzip -ssw -mx5 $archiv $source

7z a .zip subdir\
