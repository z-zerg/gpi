﻿# принимаются Action (Mount, Unmount, Check), Target (Disk или Folder)
param(
[string]$Action,
[string]$Target,
[string]$FolderName,
[string]$DiskName,
[string]$checkTarget
)

# Папка с файлами VHD
$VHD_FolderPath = "\\advanta\vhd$"

# Путь к VHD файлу  для подключения
$VHD_FilePath = $VHD_FolderPath + "\" + $env:COMPUTERNAME + ".vhd"


$DefaultTarget = "Folder"
$DefaultAction = "Check"
$DefaultMountFolderName = "stdProgramms"
$DefaultMountDisk = "P"
$DefaultCheckTarget = "\\geops.local\vhd$"


# Список закрываемых программ
$ListSoftKill = @(
"chrome",
"Radmin",
"TOTALCMD64",
"IMC",
"xnview",
"i_view64",
"global_mapper",
"ustation",
"OUTLOOK",
"WINWORD",
"POWERPNT",
"EXCEL",
"MSACCESS",
"acad",
"acwebbrowser",
"Acrobat"
)


if (!$Action){
    $Action = $DefaultAction
} 

if (!$Target){
    $Target = $DefaultTarget
} 

if (!$MountFolderName){
    $MountFolderName = $DefaultMountFolderName
} 

IF (!$DiskName){
    $DiskName = $DefaultMountDisk
} 

if (!$checkTarget){
    $checkTarget = $DefaultCheckTarget
}



$commandPath = "cmd.exe"

$MountFolder = $env:ProgramW6432 + "\" + $MountFolderName
$MountFolder_x86 = ${env:ProgramFiles(x86)} + "\" + $MountFolderName




# массив команд для diskpart
$runProc=@{
    "attach"= "/c `"(echo select vdisk file=`"$VHD_FilePath`" && echo attach vdisk) | diskpart`"";
    "detach"= "/c `"(echo select vdisk file=`"$VHD_FilePath`" && echo remove all dismount && echo detach vdisk) | diskpart`"";
    "list_vol"= "/c `"echo list volume | diskpart`"";
    "AssignToFolder"= "/c `"(echo select volume={0} && echo assign mount=`"{1}`") | diskpart`"";
    "AssignToDisk"= "/c `"(echo select volume={0} && echo assign letter={1}) | diskpart`"";
    "dismount"= "/c `"(echo select volume={0} && echo remove all) | diskpart`"";
}



# Выполняем diskpart в соответствии с переданным параметром (действие из массива runProc)
function cmdDo ($ArgStr) {

    $myProcInfo = New-Object System.Diagnostics.ProcessStartInfo
    $myProcInfo.FileName = $commandPath
    $myProcInfo.Arguments = $ArgStr
    $myProcInfo.RedirectStandardError=$true
    $myProcInfo.RedirectStandardOutput=$true
    $myProcInfo.UseShellExecute=$false
    $myProcInfo.StandardOutputEncoding=[System.Text.Encoding]::GetEncoding('cp866')
    $myProc = New-Object System.Diagnostics.Process
    $myProc.StartInfo=$myProcInfo
    $myProc.Start() | Out-Null
    $myProc.WaitForExit()
    $outText = $myProc.StandardOutput.ReadToEnd()
    return $outText
}


function listVolumes{
    return cmdDo $runProc["list_vol"]
}

# По результатам отработки diskpart получаем список подключенных томов 
function getVolumes{
param($RegExpStr = "Том [0-9]")

    $ResultDiskpart = cmdDo $runProc["list_vol"]
    $arrStr = $ResultDiskpart -split '\n'
    [System.Collections.ArrayList] $newArr = @{}

    for ($i=0; $i -lt $arrStr.Count; $i++){
    
        if ($arrStr[$i] -match $RegExpStr){
            $newArr += $arrStr[$i]
        }
    }
    return $newArr
}



# Определим номер тома с указанной меткой(по умолчанию Programs)
function getVolumeNumberName {
param($label="Programms")
    $volumes = getVolumes
    for ($i=0; $i -lt $volumes.Count; $i++){
        if ($volumes[$i] -match $label){
            $numVol = [Convert]::ToInt32($volumes[$i][9],10)
            return $numVol
        } 
    }
    return $false
       
}


# Определим номер тома с указанной буквой(по умолчанию P)
function getVolumeNumberLetter {
param($letter = $DiskName)
    $volumes = getVolumes $DefaultMountDisk
    for ($i=0; $i -lt $volumes.Count; $i++){
        if ($volumes[$i] -match " " + $letter + " "){
            return $numVol = [Convert]::ToInt32($volumes[$i][9],10)
        } 
    }
    return $false     
}





# Проверим доступность буквы диска
function checkMountDisk{
param ($letter = $Global:DiskName)
    
    if (($numVol = getVolumeNumberName) -ne $false){
        Write-Host "Файл диска уже подключен"
        
        if (($numVol = getVolumeNumberLetter) -ne $false){
            Write-Host "Буква диска уже назначена"       
        }
    }
    
    return $numVol   
}


# Проверим разрядность ОС
function is64bit {
    return [System.Environment]::Is64BitOperatingSystem
        
}


# Проверим доступность подключаемой папки
function checkMountFolder{  

    $list = listVolumes

    if ((Test-Path $MountFolder) -eq $false){
        New-Item -Path $MountFolder -ItemType directory -Force | Out-Null               
    }
        

    if (is64bit){
        if ((Test-Path $MountFolder_x86) -eq $false){
            New-Item -Path $MountFolder_x86 -ItemType directory -Force | Out-Null          
        }        
    }
    
    return $numVol
}



# Подключение виртуального диска к диску
function AssignToDisk{
param($MountDiskLetter = $Global:DiskName)       
    $numVol = getVolumeNumberName  
    if ((getVolumeNumberLetter) -eq $false){
        Write-Host "Назначаем диск"
        cmdDo ($($runProc["AssignToDisk"] -f $numVol, $MountDiskLetter)) 
        return
    }
    Write-Host "Диск уже назначен"
    return
}



# Подключение виртуального диска к папке
function AssignToFolder{
    
    if (($numVol = getVolumeNumberName) -ne $false){
        
        if (is64bit){
            if ((getVolumes ([regex]::Escape($MountFolder_x86))) -ne $null){
                Write-Host "Папка уже назначена"        
            } else {
                cmdDo ($($runProc["AssignToFolder"] -f $numVol, $MountFolder_x86))
            }            
        }
        

        if ((getVolumes ([regex]::Escape($MountFolder))) -ne $null){
            Write-Host "Папка уже назначена"        
        } else {
            cmdDo ($($runProc["AssignToFolder"] -f $numVol, $MountFolder))
        }        
    }
}



# Подключаем файл виртуального диска
function Attach{
    if ((getVolumeNumberName) -ne $false){       
        Write-Host "Файл диска уже подключен"
        return
    }
    
    if ((Test-Path $VHD_FilePath) -ne $true){
        Write-Host "Файл диска недоступен. Завершаем программу"
        Start-Sleep 3
        Exit
    }
    Detach
    cmdDo ($($runProc["attach"]))
    return
}


# Отключение виртуального диска
function Detach{
    Dismount
    Start-Sleep 2
    cmdDo $runProc["detach"]
    if ((Test-Path $MountFolder) -eq$true){
        Remove-Item $MountFolder -Force -Confirm:$false
    }  
    if ((Test-Path $MountFolder_x86) -eq$true){
        Remove-Item $MountFolder_x86 -Force -Confirm:$false
    }   
}



function Dismount{
param ($numVol)

    if ($numVol -eq $null){
        $numVol = getVolumeNumberName
    }

    if ($numVol -ne $false){
        cmdDo ($($runProc["dismount"] -f $numVol))
    }
    

    if ((Test-Path $MountFolder) -eq $true){
        Remove-Item $MountFolder -Force -Recurse -Confirm:$false
    }
    if (is64bit){
        if ((Test-Path $MountFolder_x86) -eq $true){
            Remove-Item $MountFolder_x86 -Force -Recurse -Confirm:$false
        }
    }
    
}



# Закрываем процесс по имени
function KillProc {
param ($name)    
    # Если имя процесса получено - закрываем, иначем закрываем по списку
    if (($name) -or ($name -ne $null)){
        Stop-Process -Name $name -Force -ErrorAction SilentlyContinue             
    } else {
        Write-Host "Не указано имя процесса. Закрываем по списку"
        foreach ($name in $ListSoftKill){
            Stop-Process -Name $name -Force -ErrorAction SilentlyContinue
        }    
    }
    return
}


# Проверка
function Check {
param($check)
    if (!$check){
        $check = $checkTarget
        Write-Host "Начинаем проверку доступности контрольного ресурса $check"
        for ($i=1; $i -lt 5; $i++){    
        Write-Host "Проверка № $i"
            if ((Test-Path $check) -eq $true){            
                VhdMount $Target
                return
            }
            Start-Sleep 5
        }
    }
 
    Write-Host "Проверка не удалась. Закрываем программы и отключаем" $Target
    KillProc
    Detach 
    return $false  
}




# Подключение виртуального диска
function VhdMount{
param($target = $DefaultTarget)
    
    Attach

    switch ($target)
    {
        Disk {$numVol = checkMountDisk}
        Folder {$numVol = checkMountFolder}    
    }   
     

    switch ($target)
    {
        Disk {AssignToDisk}
        Folder {AssignToFolder}
    }       
}





switch ($Action)
{
    Mount
    {
        VhdMount $Target
    }

    Check
    {
        Check       
    }

    Detach
    {
        Detach
    }
}
